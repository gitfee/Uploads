﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common
{
    public class ConstLib
    {
        public static string servername = "tcp://52.201.223.43:9007/amps/json";

        public static string[] topics = { "test1","test2","test3"};
    }
}
