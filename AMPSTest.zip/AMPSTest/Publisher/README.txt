README for AMPS Client for .NET 5.3.0.0
===============================

Thanks for choosing AMPS! This client redistributable contains everything
necessary to begin building AMPS applications on Microsoft Windows.

To begin using the AMPS client, read the AMPS C# Development Guide located
in the doc\ directory. 



